A Python module written by Maxime Chalon <maxime.chalon@gmail.com>
that wraps the Clipper library can be downloaded from:

https://sites.google.com/site/maxelsbackyard/home/pyclipper